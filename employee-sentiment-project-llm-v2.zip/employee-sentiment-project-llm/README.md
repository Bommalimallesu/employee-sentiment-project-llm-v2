# Employee Sentiment Analysis (LLM-based)

This project analyzes employee communications using **HuggingFace DistilBERT sentiment model**.

## Features
- LLM-based sentiment (positive/negative/neutral)
- EDA & visualizations
- Monthly sentiment scores
- Employee ranking (top 3 positive & negative per month)
- Flight risk detection (>=4 negatives in 30 days)
- Linear regression on monthly features

## Usage
1. Place dataset at `data/test.xlsx` or `data/test.csv`.
2. Run `notebooks/Employee_Sentiment_Analysis.ipynb`.
3. Outputs: `labeled_output.csv`, `monthly_aggregates.csv`, charts in `visualization/`.

## Requirements
```bash
pip install pandas numpy matplotlib scikit-learn transformers torch openpyxl
```

## Notes
- Sentiment powered by HuggingFace `distilbert-base-uncased-finetuned-sst-2-english`.
- Data not included due to privacy. Place your file in `data/`.


## Outputs
- `data/labeled_output.csv` – every message with LLM sentiment score/label
- `data/monthly_aggregates.csv` – monthly features & scores per employee
- `visualization/*.png` – saved charts (distribution, messages/day, avg score)

## Environment Variables
An optional `.env.example` is included for future API integrations.

## GitHub Safety
A `.gitignore` is included to prevent pushing raw data or large images.
